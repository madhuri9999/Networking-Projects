﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class King : GameItem
    {
        public King(int color, int x, int y) : base(GameItemKind.KING, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            if (Math.Abs(mX - x) > 1 || Math.Abs(mY - y) > 1)
                return false;

            return true;
        }
    }
}
