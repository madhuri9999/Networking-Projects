﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class Rook : GameItem
    {
        public Rook(int color, int x, int y) : base(GameItemKind.ROOK, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            int iDeltaX = x - mX;
            int iDeltaY = y - mY;

            int iAbsDeltaX = Math.Abs(iDeltaX);
            int iAbsDeltaY = Math.Abs(iDeltaY);

            int iMinusX = iAbsDeltaX == 0 ? 0 : iDeltaX / iAbsDeltaX;
            int iMinusY = iAbsDeltaY == 0 ? 0 : iDeltaY / iAbsDeltaY;

            if (iAbsDeltaX > 0 && iAbsDeltaY > 0)
                return false;

            if (iAbsDeltaX > 0)
            {
                x -= iMinusX;
                while (Math.Abs(x - mX) > 1)
                {
                    if (items[y, x] != null && items[y, x].IsAlive)
                        return false;
                    x -= iMinusX;
                }
            }
            else if (iAbsDeltaY > 0)
            {
                y -= iMinusY;
                while (Math.Abs(y - mY) > 1)
                {

                    if (items[y, x] != null && items[y, x].IsAlive)
                        return false;

                    y -= iMinusY;
                }
            }

            return true;
        }
    }
}
