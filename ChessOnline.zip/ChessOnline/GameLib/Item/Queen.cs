﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class Queen : GameItem
    {
        public Queen(int color, int x, int y) : base(GameItemKind.QUEEN, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            int iDeltaX = x - mX;
            int iDeltaY = y - mY;

            int iAbsDeltaX = Math.Abs(iDeltaX);
            int iAbsDeltaY = Math.Abs(iDeltaY);

            int iMinusX = iAbsDeltaX == 0 ? 0 : iDeltaX / iAbsDeltaX;
            int iMinusY = iAbsDeltaY == 0 ? 0 : iDeltaY / iAbsDeltaY;

            bool bMovable = (iAbsDeltaX == iAbsDeltaY) || (iAbsDeltaX + iAbsDeltaY == iAbsDeltaX) || (iAbsDeltaX + iAbsDeltaY == iAbsDeltaY);
            if (!bMovable)
                return false;

            if (iAbsDeltaX == 0)
            {
                y -= iMinusY;
                while (y != mY)
                {
                    if (items[y, x] != null && items[y, x].IsAlive)
                        return false;
                    y -= iMinusY;
                };
            }
            else if (iAbsDeltaY == 0)
            {
                x -= iMinusX;
                while (x != mX)
                {
                    if (items[y, x] != null && items[y, x].IsAlive)
                        return false;
                    x -= iMinusX;
                }
            }
            else
            {
                x -= iMinusX;
                y -= iMinusY;

                while (x != mX && y != mY)
                {
                    if (items[y, x] != null && items[y, x].IsAlive)
                        return false;
                    x -= iMinusX;
                    y -= iMinusY;
                }
            }

            return true;
        }
    }
}
