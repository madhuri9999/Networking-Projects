﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class Bishop : GameItem
    {
        public Bishop(int color, int x, int y) : base(GameItemKind.BISHOP, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            if (Math.Abs(mX - x) != Math.Abs(mY - y))
                return false;

            int iMinusX = (x - mX) / Math.Abs(x - mX);
            int iMinusY = (y - mY) / Math.Abs(y - mY);

            x -= iMinusX;
            y -= iMinusY;
            while (x != mX && y != mY)
            {
                if (items[y, x] != null && items[y, x].IsAlive)
                    return false;

                x -= iMinusX;
                y -= iMinusY;
            }

            return true;
        }
    }
}
