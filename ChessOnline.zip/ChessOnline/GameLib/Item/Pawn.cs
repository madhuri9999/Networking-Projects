﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class Pawn : GameItem
    {
        public Pawn(int color, int x, int y) : base(GameItemKind.PAWN, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            int iDeltaY = y - mY;

            if (iDeltaY == 0 ||
                    (mColor == GameItemKind.BLACK && iDeltaY < 0) ||
                    (mColor == GameItemKind.WHITE && iDeltaY > 0) ||
                    (Math.Abs(iDeltaY) > 2 || (mIsMoved && Math.Abs(iDeltaY) > 1)))
                return false;

            if (Math.Abs(iDeltaY) > 1)
            {
                y -= iDeltaY / Math.Abs(iDeltaY);
                if (items[y, x] != null && items[y, x].IsAlive)
                    return false;
            }
            return true;
        }
    }
}
