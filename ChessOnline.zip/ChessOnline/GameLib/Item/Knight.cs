﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Item
{
    public class Knight : GameItem
    {
        public Knight(int color, int x, int y) : base(GameItemKind.KNIGHT, color)
        {
            mX = x;
            mY = y;
        }

        public override bool CheckCanMove(int x, int y, GameItem[,] items)
        {
            bool bMovable = false;
            int iDeltaX = x - mX;
            int iDeltaY = y - mY;
            bMovable =
                    (iDeltaX == -2 && iDeltaY == -1) ||
                    (iDeltaX == -1 && iDeltaY == -2) ||
                    (iDeltaX == 2 && iDeltaY == -1) ||
                    (iDeltaX == 1 && iDeltaY == -2) ||
                    (iDeltaX == -2 && iDeltaY == 1) ||
                    (iDeltaX == -1 && iDeltaY == 2) ||
                    (iDeltaX == 2 && iDeltaY == 1) ||
                    (iDeltaX == 1 && iDeltaY == 2);

            if (!bMovable)
                return false;

            return bMovable;
        }
    }
}
