﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib.Net
{
    public class DataPacketType
    {
        public const int PLAYERNAME             = 0x2800;
        public const int HEARTBIT               = 0x2801;
        public const int ADDPLAYER              = 0x2802;
        public const int DELPLAYER              = 0x2803;
        public const int EXIT                   = 0x2804;
        public const int PLAYERLIST             = 0x2805;

        public const int REQPLAY                = 0x2806;
        public const int DENY                   = 0x2807;
        public const int ACCEPT                 = 0x2808;
        public const int STARTGAME              = 0x2809;
        public const int MOVEITEM               = 0x280A;
        public const int GAMERESULT             = 0x280B;
        public const int EXITGAME               = 0x280C;
        public const int RESIGN                 = 0x280D;
        public const int PROMOTION              = 0x280E;
    }
}
