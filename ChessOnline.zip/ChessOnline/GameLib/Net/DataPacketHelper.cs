﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib.Net
{
    public class DataPacketHelper
    {
        public static string ConvertBytesToString(byte[] buffer, int iOffset, int iLength)
        {
            return Encoding.UTF8.GetString(buffer, iOffset, iLength);
        }

        public static byte[] ConvertLongToBytes(long lValue)
        {
            return BitConverter.GetBytes(lValue);
        }
        public static long ConvertBytesToLong(byte[] arrBytes, int iOffset)
        {
            return BitConverter.ToInt64(arrBytes, iOffset);
        }

        public static byte[] ConvertIntToBytes(int iValue)
        {
            return BitConverter.GetBytes(iValue);
        }
        public static int ConvertBytesToInt(byte[] arrBytes, int iOffset)
        {
            return BitConverter.ToInt32(arrBytes, iOffset);
        }
    }
}
