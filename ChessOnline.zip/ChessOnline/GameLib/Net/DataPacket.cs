﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GameLib.Game;

namespace GameLib.Net
{
    public class DataPacket
    {
        /**
         * 
         * Packet Structure
         * 
         * [SIGNATURE][LENGTH OF CONTENT][PACKET TYPE][  CONTENT  ]
         * [ 4 BYTES ][      4 BYTES    ][  4 BYTES  ][ VARIABLE  ]
         * 
         * 
        **/
        public const int BUFFER_SIZE = 512;

        public const int SIGNATURE = 0x0330;
        
        private int mType;
        private long mTicks;
        private int mContentLength;
        private object mContent;

        public long Ticks { get { return mTicks; } }
        public int ContentLength { get { return mContentLength; } }
        public int Type { get { return mType; } }
        public object Content { get { return mContent; } }
        
        private DataPacket()
        {
            mType = 0;
            mTicks = 0;
            mContentLength = 0;
            mContent = null;
        }

        public static DataPacket Build(int iType, object data)
        {
            try
            {
                DataPacket packet = new DataPacket();
                packet.mType = iType;
                packet.mTicks = DateTime.Now.Ticks;

                int[] arrTemp;
                byte[] arr;

                switch (iType)
                {
                    case DataPacketType.HEARTBIT:
                    case DataPacketType.EXIT:
                    case DataPacketType.EXITGAME:
                    case DataPacketType.RESIGN:
                        packet.mContent = "";
                        packet.mContentLength = 0;
                        break;
                    case DataPacketType.PLAYERNAME:
                    case DataPacketType.ADDPLAYER:
                    case DataPacketType.REQPLAY:
                    case DataPacketType.ACCEPT:
                    case DataPacketType.DENY:
                        packet.mContent = data;
                        packet.mContentLength = packet.mContent.ToString().Length;
                        break;
                    case DataPacketType.DELPLAYER:
                        packet.mContentLength = 4;
                        packet.mContent = DataPacketHelper.ConvertIntToBytes((int)data);
                        break;
                    case DataPacketType.PLAYERLIST:
                        string strData = "";
                        List<GameClientInfo> arrUsers = (List<GameClientInfo>)data;
                        for (int i = 0; i < arrUsers.Count; i++)
                        {
                            strData += arrUsers[i].ToString() + ";";
                        }
                        packet.mContentLength = strData.Length;
                        packet.mContent = strData;
                        break;
                    case DataPacketType.STARTGAME:
                        packet.mContentLength = ((byte[])data).Length;
                        packet.mContent = data;
                        break;
                    case DataPacketType.PROMOTION:
                        arrTemp = (int[])data;
                        packet.mContentLength = 4 * arrTemp.Length;
                        packet.mContent = new byte[packet.mContentLength];
                        for (int i = 0; i < arrTemp.Length; i++)
                        {
                            arr = DataPacketHelper.ConvertIntToBytes(arrTemp[i]);
                            ((byte[])packet.mContent)[4 * i] = arr[0];
                            ((byte[])packet.mContent)[4 * i + 1] = arr[1];
                            ((byte[])packet.mContent)[4 * i + 2] = arr[2];
                            ((byte[])packet.mContent)[4 * i + 3] = arr[3];
                        }
                        break;
                    case DataPacketType.MOVEITEM:
                        arrTemp = (int[])data;
                        packet.mContentLength = 4 * (4 * arrTemp[0] + 2);
                        packet.mContent = new byte[packet.mContentLength];

                        arr = DataPacketHelper.ConvertIntToBytes(arrTemp[0]);
                        ((byte[])packet.mContent)[0] = arr[0];
                        ((byte[])packet.mContent)[1] = arr[1];
                        ((byte[])packet.mContent)[2] = arr[2];
                        ((byte[])packet.mContent)[3] = arr[3];

                        for (int i = 1; i < arrTemp.Length - 1; i++)
                        {
                            arr = DataPacketHelper.ConvertIntToBytes(arrTemp[i]);
                            ((byte[])packet.mContent)[4 + 4 * (i - 1)] = arr[0];
                            ((byte[])packet.mContent)[4 + 4 * (i - 1) + 1] = arr[1];
                            ((byte[])packet.mContent)[4 + 4 * (i - 1) + 2] = arr[2];
                            ((byte[])packet.mContent)[4 + 4 * (i - 1) + 3] = arr[3];
                        }

                        arr = DataPacketHelper.ConvertIntToBytes(arrTemp[arrTemp.Length - 1]);
                        ((byte[])packet.mContent)[packet.mContentLength - 4] = arr[0];
                        ((byte[])packet.mContent)[packet.mContentLength - 3] = arr[1];
                        ((byte[])packet.mContent)[packet.mContentLength - 2] = arr[2];
                        ((byte[])packet.mContent)[packet.mContentLength - 1] = arr[3];
                        break;
                    case DataPacketType.GAMERESULT:
                        packet.mContentLength = 1;
                        packet.mContent = (byte)data;
                        break;
                }
                return packet;
            }
            catch { }
            return null;

        }
	
	    public byte[] GetBytes()
        {
            List<byte> arrData = new List<byte>();
            arrData.AddRange(DataPacketHelper.ConvertIntToBytes(SIGNATURE));
            arrData.AddRange(DataPacketHelper.ConvertLongToBytes(mTicks));
            arrData.AddRange(DataPacketHelper.ConvertIntToBytes(mContentLength));
            arrData.AddRange(DataPacketHelper.ConvertIntToBytes(mType));
		
		    switch(mType) {
		    case DataPacketType.PLAYERNAME:
		    case DataPacketType.ADDPLAYER:
		    case DataPacketType.PLAYERLIST:
		    case DataPacketType.REQPLAY:
		    case DataPacketType.ACCEPT:
		    case DataPacketType.DENY:
                arrData.AddRange(Encoding.UTF8.GetBytes(mContent.ToString()));
			    break;
		    case DataPacketType.DELPLAYER:
		    case DataPacketType.STARTGAME:
		    case DataPacketType.MOVEITEM:
		    case DataPacketType.PROMOTION:
                arrData.AddRange((byte[])mContent);
			    break;
		    case DataPacketType.HEARTBIT:		
		    case DataPacketType.EXIT:	
		    case DataPacketType.EXITGAME:
		    case DataPacketType.RESIGN:
			    break;
		    case DataPacketType.GAMERESULT:
			    arrData.Add((byte)mContent);
			    break;
		    }

            return arrData.ToArray();
	    }
	
        public static DataPacket Parse(byte[] buffer)
        {
            DataPacket packet = new DataPacket();

            try
            {
                int iSignature = DataPacketHelper.ConvertBytesToInt(buffer, 0);

                if (iSignature != DataPacket.SIGNATURE)
                    throw new Exception("Invalid Signature Code!");

                packet.mTicks = DataPacketHelper.ConvertBytesToLong(buffer, 4);
                packet.mContentLength = DataPacketHelper.ConvertBytesToInt(buffer, 12);
                packet.mType = DataPacketHelper.ConvertBytesToInt(buffer, 16);

                int[] arrContent;
                switch (packet.mType)
                {
                    case DataPacketType.PLAYERNAME:
                        packet.mContent = DataPacketHelper.ConvertBytesToString(buffer, 20, packet.mContentLength);
                        break;
                    case DataPacketType.HEARTBIT:
                    case DataPacketType.EXIT:
                    case DataPacketType.EXITGAME:
                    case DataPacketType.RESIGN:
                        packet.mContent = "";
                        break;
                    case DataPacketType.ADDPLAYER:
                    case DataPacketType.REQPLAY:
                    case DataPacketType.ACCEPT:
                    case DataPacketType.DENY:
                        packet.mContent = GameClientInfo.Parse(DataPacketHelper.ConvertBytesToString(buffer, 20, packet.mContentLength));
                        break;
                    case DataPacketType.DELPLAYER:
                        packet.mContent = DataPacketHelper.ConvertBytesToInt(buffer, 20);
                        break;
                    case DataPacketType.PLAYERLIST:
                        List<GameClientInfo> arrUsers = new List<GameClientInfo>();
                        string[] arrInfo = DataPacketHelper.ConvertBytesToString(buffer, 20, packet.mContentLength).Split(';');
                        for (int i = 0; i < arrInfo.Length; i++)
                        {
                            if (arrInfo[i] == "") continue;
                            GameClientInfo info = GameClientInfo.Parse(arrInfo[i]);
                            if (info != null)
                                arrUsers.Add(info);
                        }
                        packet.mContent = arrUsers;
                        break;
                    case DataPacketType.STARTGAME:
                        packet.mContent = new byte[packet.mContentLength];
                        Array.Copy(buffer, 20, (byte[])packet.mContent, 0, packet.mContentLength);
                        break;
                    case DataPacketType.MOVEITEM:
                        int iTemp = DataPacketHelper.ConvertBytesToInt(buffer, 20);
                        arrContent = new int[4 * iTemp + 2];
                        arrContent[0] = iTemp;
                        
                        for (int i = 0; i < 4 * iTemp + 1; i++)
                        {
                            arrContent[i + 1] = DataPacketHelper.ConvertBytesToInt(buffer, 24 + 4 * i);
                        }

                        packet.mContent = arrContent;
                        break;
                    case DataPacketType.GAMERESULT:
                        packet.mContent = buffer[20];
                        break;
                    case DataPacketType.PROMOTION:
                        arrContent = new int[packet.mContentLength / 4];
                        for (int i = 0; i < packet.mContentLength / 4; i++)
                        {
                            arrContent[i] = DataPacketHelper.ConvertBytesToInt(buffer, 20 + 4 * i);
                        }
                        packet.mContent = arrContent;
                        break;
                }
            }
            catch
            {
                return null;
            }
            return packet;
        }
    }
}
