﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib.Game
{
    public interface GameBoardInterface
    {
        void ShowPromotionForm();

        void MoveItem(int iOldX, int iOldY, int iNewX, int iNewY);

        void MoveItem(int iOldX1, int iOldY1, int iNewX1, int iNewY1, int iOldX2, int iOldY2, int iNewX2, int iNewY2);

        void EndGame(bool bWin, bool bIsByMine);

        void SendPromotion(int iOldX, int iOldY, int iNewX, int iNewY, int iType);
    }
}
