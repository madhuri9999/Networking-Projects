﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib.Game
{
    public class GameClientInfo
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public GameClientInfo(int iId, string strName)
        {
            ID = iId;
            Name = strName;
        }

        public override string ToString()
        {
            return ID + "&^^&" + Name;
        }

        public static GameClientInfo Parse(string strInfo)
        {
            try
            {
                string[] arrInfo = strInfo.Split(new string[] { "&^^&" }, StringSplitOptions.None);
                return new GameClientInfo(int.Parse(arrInfo[0]), arrInfo[1]);
            }
            catch { }
            return null;
        }
    }
}
