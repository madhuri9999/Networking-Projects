﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.Drawing;
using GameLib.Item;

namespace GameLib.Game
{
    public class GameBoard : PictureBox
    {
        private const int ITEM_WIDTH = 75;

        public const int ROWS = 8;
        public const int COLS = 8;

        private GameItem[,] mBoardItems = null;
        private List<GameItem> mAllGameItems;

        private GameItem mSelectedItem;

        private Brush mBrushDark, mBrushLight, mBrushSelected;

        private bool mCanMove;
        public bool CanMove { get { return mCanMove; } set { mCanMove = value; } }

        private int mPlayerColor;
        public int PlayerColor { get { return mPlayerColor; } set { mPlayerColor = value; } }

        private GameItem mPromotionItem;
        private int mPromotionX;
        private int mPromotionY;

        private GameBoardInterface mBoardInterface;
        public void SetBoardInterface(GameBoardInterface boardInterface)
        {
            mBoardInterface = boardInterface;
        }

        public GameBoard()
        {
            mBoardItems = new GameItem[ROWS, COLS];
            mAllGameItems = new List<GameItem>();
            for (int x = 0; x < COLS; x++)
            {
                for (int y = 0; y < ROWS; y++)
                {
                    mBoardItems[y, x] = null;
                }
            }

            mSelectedItem = null;
            mCanMove = false;

            mBrushDark = new SolidBrush(Color.FromArgb(0xff, 0x76, 0x96, 0x56));
            mBrushLight = new SolidBrush(Color.FromArgb(0xff, 0xee, 0xee, 0xd2));
            mBrushSelected = new SolidBrush(Color.FromArgb(0xff, 0xba, 0xcb, 0x44));
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);

            Graphics g = pe.Graphics;

            for (int y = 0; y < ROWS; y++)
            {
                for (int x = 0; x < COLS; x++)
                {
                    g.FillRectangle(
                        ((mSelectedItem != null && x == mSelectedItem.X && y == mSelectedItem.Y) ? mBrushSelected :
                            ((x + y % 2) % 2 == 0 ? mBrushLight : mBrushDark)), x * ITEM_WIDTH, y * ITEM_WIDTH, ITEM_WIDTH, ITEM_WIDTH);
                    if (mBoardItems[y, x] != null && mBoardItems[y, x].IsAlive && mBoardItems[y, x].ItemImage != null)
                    {
                        g.DrawImage(mBoardItems[y, x].ItemImage, x * ITEM_WIDTH, y * ITEM_WIDTH, ITEM_WIDTH, ITEM_WIDTH);
                    }
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (!mCanMove)
                return;

            int x = e.X / ITEM_WIDTH;
            int y = e.Y / ITEM_WIDTH;

            GameItem item = null;
            int i = 0;
            for (i = 0; i < mAllGameItems.Count; i++)
            {
                item = mAllGameItems[i];
                if (item.X == x && item.Y == y && item.IsAlive)
                {
                    break;
                }
            }

            bool bIsEmpty = i >= mAllGameItems.Count;

            if (mSelectedItem == null)
            {
                if (!bIsEmpty && item.Color == mPlayerColor)
                    mSelectedItem = item;
            }
            else if (!bIsEmpty && mSelectedItem == item)
            {
                mSelectedItem = null;
            }
            else
            {
                bool bMovable = mSelectedItem.CheckCanMove(x, y, mBoardItems);

                if (bMovable)
                {
                    if (!bIsEmpty)
                    {
                        if (mSelectedItem.Color == item.Color)
                            bMovable = false;
                    }

                    if (bMovable)
                        bMovable = checkItemMove(mSelectedItem, mBoardItems[y, x], x, y);

                    if (mSelectedItem is Pawn &&
                                ((mSelectedItem.Color == GameItemKind.WHITE && y == 0) ||
                                 (mSelectedItem.Color == GameItemKind.BLACK && y == ROWS - 1)))
                    {
                        mPromotionItem = mSelectedItem;
                        mPromotionX = x;
                        mPromotionY = y;
                        mBoardInterface.ShowPromotionForm();
                    }
                    else
                    {
                        if (bMovable)
                        {
                            mBoardInterface.MoveItem(mSelectedItem.X, mSelectedItem.Y, x, y);
                            mBoardItems[y, x] = mBoardItems[mSelectedItem.Y, mSelectedItem.X];
                            mBoardItems[mSelectedItem.Y, mSelectedItem.X] = null;
                            mSelectedItem.MoveTo(x, y);

                            checkGameResult();
                        }
                    }
                }

                mSelectedItem = null;
            }

            Invalidate();
        }

        private void checkGameResult()
        {
            for (int i = 0; i < mAllGameItems.Count; i++)
            {
                GameItem item = mAllGameItems[i];
                if (!item.IsAlive && item is King)
                {
                    mBoardInterface.EndGame(item.Color != mPlayerColor, true);
                }
            }
        }
        private bool checkItemMove(GameItem itemSrc, GameItem itemDes, int iDesX, int iDesY)
        {
            if (itemSrc is Pawn)
            {
                if (itemSrc.X - iDesX != 0 && (itemDes == null || !itemDes.IsAlive))
                {
                    return false;
                }
                if (Math.Abs(itemSrc.X - iDesX) > 1)
                    return false;

                if (itemDes != null && itemDes.IsAlive)
                {
                    itemDes.Die();
                }
                else
                {
                    GameItem item = null;
                    if (itemSrc.Color == GameItemKind.WHITE &&
                        itemSrc.Y == 6 && iDesY == 4)
                    {
                        if (itemSrc.X > 0)
                        {
                            item = mBoardItems[iDesY, itemSrc.X - 1];
                            if (item != null && item.IsAlive && item.Color != itemSrc.Color && item is Pawn)
                            {
                                itemSrc.Die();
                                mBoardItems[iDesY + 1, itemSrc.X] = item;
                                mBoardItems[iDesY, itemSrc.X - 1] = null;
                                item.MoveTo(itemSrc.X, iDesY + 1);
                            }
                        }
                        if (itemSrc.X < COLS - 1)
                        {
                            item = mBoardItems[iDesY, itemSrc.X + 1];
                            if (item != null && item.IsAlive && item.Color != itemSrc.Color && item is Pawn)
                            {
                                itemSrc.Die();
                                mBoardItems[iDesY + 1, itemSrc.X] = item;
                                mBoardItems[iDesY, itemSrc.X + 1] = null;
                                item.MoveTo(itemSrc.X, iDesY + 1);
                            }
                        }
                    }
                    else if (itemSrc.Color == GameItemKind.BLACK &&
                          itemSrc.Y == 1 && iDesY == 3)
                    {

                        if (itemSrc.X > 0)
                        {
                            item = mBoardItems[iDesY, itemSrc.X - 1];
                            if (item != null && item.IsAlive && item.Color != itemSrc.Color && item is Pawn)
                            {
                                itemSrc.Die();
                                mBoardItems[iDesY - 1, itemSrc.X] = item;
                                mBoardItems[iDesY, itemSrc.X - 1] = null;
                                item.MoveTo(itemSrc.X, iDesY - 1);
                            }
                        }
                        if (itemSrc.X < COLS - 1)
                        {
                            item = mBoardItems[iDesY, itemSrc.X + 1];
                            if (item != null && item.IsAlive && item.Color != itemSrc.Color && item is Pawn)
                            {
                                itemSrc.Die();
                                mBoardItems[iDesY - 1, itemSrc.X] = item;
                                mBoardItems[iDesY, itemSrc.X + 1] = null;
                                item.MoveTo(itemSrc.X, iDesY - 1);
                            }
                        }
                    }
                }
            }
            else
            {
                if (itemDes != null)
                {
                    itemDes.Die();
                }

            }

            return true;
        }

        public void PromotionByOther(int[] arrInfo)
        {
            mPromotionItem = mBoardItems[arrInfo[1], arrInfo[0]];
            mPromotionItem.Die();
            mPromotionX = arrInfo[2];
            mPromotionY = arrInfo[3];

            int iColor = mPlayerColor == GameItemKind.BLACK ? GameItemKind.WHITE : GameItemKind.BLACK;
            GameItem newItem = null;
            try
            {
                switch (arrInfo[4])
                {
                    case GameItemKind.QUEEN:
                        newItem = new Queen(iColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.ROOK:
                        newItem = new Rook(iColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.KNIGHT:
                        newItem = new Knight(iColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.BISHOP:
                        newItem = new Bishop(iColor, mPromotionX, mPromotionY);
                        break;
                }
                if (mBoardItems[mPromotionY, mPromotionX] != null)
                    mBoardItems[mPromotionY, mPromotionX].Die();

                mAllGameItems.Add(newItem);
                mBoardItems[mPromotionY, mPromotionX] = newItem;
            }
            catch { }
            Invalidate();
        }

        public void PromotionBySelf(int iType)
        {
            mPromotionItem.Die();
            GameItem newItem = null;
            try
            {
                switch (iType)
                {
                    case GameItemKind.QUEEN:
                        newItem = new Queen(mPlayerColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.ROOK:
                        newItem = new Rook(mPlayerColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.KNIGHT:
                        newItem = new Knight(mPlayerColor, mPromotionX, mPromotionY);
                        break;
                    case GameItemKind.BISHOP:
                        newItem = new Bishop(mPlayerColor, mPromotionX, mPromotionY);
                        break;
                }
                mAllGameItems.Add(newItem);
                mBoardItems[mPromotionY, mPromotionX] = newItem;

                mBoardInterface.SendPromotion(mPromotionItem.X, mPromotionItem.Y, mPromotionX, mPromotionY, iType);
            }
            catch { }
            Invalidate();
        }

        public bool Castling()
        {
            GameItem kingItem = null;
            List<GameItem> rookItems = new List<GameItem>();

            for (int i = 0; i < mAllGameItems.Count; i++)
            {
                if (mAllGameItems[i].Color != mPlayerColor)
                    continue;

                if (mAllGameItems[i] is King)
                {
                    kingItem = mAllGameItems[i];
                }
                else if (mAllGameItems[i] is Rook && mAllGameItems[i].IsAlive)
                {
                    rookItems.Add(mAllGameItems[i]);
                }
            }
            if (kingItem == null || !kingItem.IsAlive)
                return false;

            if (rookItems.Count < 1)
                return false;

            bool bIsMoved = false;
            for (int i = 0; i < rookItems.Count; i++)
            {
                GameItem rookItem = rookItems[i];
                if (kingItem.IsMoved || rookItem.IsMoved)
                    return false;

                int iDeltaX = kingItem.X - rookItem.X;
                int iAbsDeltaX = Math.Abs(iDeltaX);
                if (kingItem.Y != rookItem.Y || iAbsDeltaX < 3)
                    return false;

                int iMinusX = iDeltaX / iAbsDeltaX;
                int iX = kingItem.X - iMinusX;

                bool bCan = true;
                while (iX != rookItem.X)
                {
                    if (mBoardItems[kingItem.Y, iX] != null)
                    {
                        bCan = false;
                        break;
                    }

                    iX -= iMinusX;
                }
                if (!bCan)
                    continue;

                int iNewKingX = kingItem.X - 2 * iMinusX;
                int iNewRookX = kingItem.X - iMinusX;

                mBoardInterface.MoveItem(kingItem.X, kingItem.Y, iNewKingX, kingItem.Y,
                                    rookItem.X, rookItem.Y, iNewRookX, rookItem.Y);

                mBoardItems[kingItem.Y, iNewKingX] = kingItem;
                mBoardItems[kingItem.Y, kingItem.X] = null;
                kingItem.MoveTo(iNewKingX, kingItem.Y);

                mBoardItems[rookItem.Y, iNewRookX] = rookItem;
                mBoardItems[rookItem.Y, rookItem.X] = null;
                rookItem.MoveTo(iNewRookX, rookItem.Y);

                bIsMoved = true;
                Invalidate();
                break;
            }

            return bIsMoved;
        }

        public void MoveItem(int iOldX, int iOldY, int iNewX, int iNewY)
        {
            checkItemMove(mBoardItems[iOldY, iOldX], mBoardItems[iNewY, iNewX], iNewX, iNewY);

            for (int i = 0; i < mAllGameItems.Count; i++)
            {
                GameItem item = mAllGameItems[i];
                if (item.X == iOldX && item.Y == iOldY)
                {
                    item.MoveTo(iNewX, iNewY);
                    break;
                }
            }
            mBoardItems[iNewY, iNewX] = mBoardItems[iOldY, iOldX];
            mBoardItems[iOldY, iOldX] = null;

            Invalidate();
        }
        public void Reset()
        {
            mBoardItems = new GameItem[ROWS, COLS];
            for (int x = 0; x < COLS; x++)
            {
                for (int y = 0; y < ROWS; y++)
                {
                    mBoardItems[y, x] = null;
                }
            }
            mAllGameItems.Clear();
            Invalidate();
        }

        public void Initialize(byte[] data)
        {
            for (int x = 0; x < COLS; x++)
            {
                for (int y = 0; y < ROWS; y++)
                {
                    if (data[y * COLS + x] > 0)
                    {
                        try
                        {
                            int iColor = (data[y * COLS + x] / 100) * 100;
                            int iType = data[y * COLS + x] % 100;
                            switch (iType)
                            {
                                case GameItemKind.BISHOP:
                                    mBoardItems[y, x] = new Bishop(iColor, x, y);
                                    break;
                                case GameItemKind.KING:
                                    mBoardItems[y, x] = new King(iColor, x, y);
                                    break;
                                case GameItemKind.QUEEN:
                                    mBoardItems[y, x] = new Queen(iColor, x, y);
                                    break;
                                case GameItemKind.KNIGHT:
                                    mBoardItems[y, x] = new Knight(iColor, x, y);
                                    break;
                                case GameItemKind.ROOK:
                                    mBoardItems[y, x] = new Rook(iColor, x, y);
                                    break;
                                case GameItemKind.PAWN:
                                    mBoardItems[y, x] = new Pawn(iColor, x, y);
                                    break;
                            }
                            mAllGameItems.Add(mBoardItems[y, x]);
                        }
                        catch { }
                    }
                }
            }
            Invalidate();
        }
    }
}
