﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace GameLib.Game
{
    public class GameItem
    {
        protected Image mImage = null;
        public Image ItemImage { get { return mImage; } }

        private const string RESFOLDER = "res/";
        private static readonly string[] STRINGSTYPE = { "k.png", "q.png", "r.png", "b.png", "n.png", "p.png" };
        private static readonly string[] STRINGSCOLOR = { "b", "w" };

        protected int mType;
        protected int mColor;
        public int Value { get { return mType + mColor; } }
        public int Color { get { return mColor; } }

        protected int mX;
        protected int mY;
        public int X { get { return mX; } }
        public int Y { get { return mY; } }
        public void MoveTo(int x, int y) { mX = x; mY = y; mIsMoved = true; }

        protected bool mIsAlive;
        public void Die() { mIsAlive = false; }
        public bool IsAlive { get { return mIsAlive; } }

        protected bool mIsMoved;
        public bool IsMoved { get { return mIsMoved; } }

        protected GameBoard mBoard;
        public void setBoard(GameBoard board)
        {
            mBoard = board;
        }

        protected GameItem(int type, int color)
        {
            if (type < GameItemKind.KING || type > GameItemKind.PAWN || color < GameItemKind.BLACK || color > GameItemKind.WHITE)
                throw new Exception("Invalid type or color!");

            mType = type;
            mColor = color;

            string strImagePath = RESFOLDER + STRINGSCOLOR[mColor / 100 - 1] + STRINGSTYPE[mType - 1];
            try
            {
                mImage = Image.FromFile(strImagePath);
            }
            catch { mImage = null; }

            mX = 0;
            mY = 0;

            mIsAlive = true;
            mIsMoved = false;
        }

        public virtual bool CheckCanMove(int x, int y, GameItem[,] items) { return false; }
    }
}
