﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib.Game
{
    public class GameItemKind
    {
        public const int KING = 1;
        public const int QUEEN = 2;
        public const int ROOK = 3;
        public const int BISHOP = 4;
        public const int KNIGHT = 5;
        public const int PAWN = 6;

        public const int BLACK = 100;
        public const int WHITE = 200;
    }
}
