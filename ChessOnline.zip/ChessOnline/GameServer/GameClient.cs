﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Threading;

using GameLib.Game;
using GameLib.Net;

namespace GameServer
{
    public class GameClient
    {
        private int mId;
        public int GetPlayerId()
        {
            return mId;
        }

        private long mLastHeartbitTime;
        public long LastHeartBitTime { get { return mLastHeartbitTime; } }
        
        public GameStatus Status { get; set; }

        public GameClient TargetPlayer { get; set; }
        
        public string PlayerName { get; set; }

        private GameServer mServer;

        private Socket mSocket;
        private NetworkStream mStream;
        private bool mIsStop;
        private byte[] mBuffer;

        private Thread mThread;

        private byte[] mBoardData;

        public GameClient(int lId, Socket sock, GameServer server)
        {
            mId = lId;
            mSocket = sock;
            mServer = server;
            PlayerName = "";
            Status = GameStatus.WAIT;
            TargetPlayer = null;
            mLastHeartbitTime = DateTime.Now.Ticks;

            mBoardData = new byte[GameBoard.ROWS * GameBoard.COLS];
            for (int x = 0; x < GameBoard.COLS; x++)
            {
                for (int y = 0; y < GameBoard.ROWS; y++)
                {
                    mBoardData[y * GameBoard.COLS + x] = 0;
                }
            }

            mStream = new NetworkStream(mSocket);

            mIsStop = false;
            mBuffer = new byte[DataPacket.BUFFER_SIZE];

            mThread = new Thread(new ThreadStart(callbackRun));
            mThread.Start();
        }
        public void InitBoard()
        {
            mBoardData[0] = mBoardData[7] = GameItemKind.BLACK + GameItemKind.ROOK;
            mBoardData[1] = mBoardData[6] = GameItemKind.BLACK + GameItemKind.KNIGHT;
            mBoardData[2] = mBoardData[5] = GameItemKind.BLACK + GameItemKind.BISHOP;
            mBoardData[3] = GameItemKind.BLACK + GameItemKind.QUEEN;
            mBoardData[4] = GameItemKind.BLACK + GameItemKind.KING;
            mBoardData[8] = mBoardData[9] = mBoardData[10] = mBoardData[11] = mBoardData[12] = mBoardData[13] = mBoardData[14] = mBoardData[15] = GameItemKind.BLACK + GameItemKind.PAWN;

            mBoardData[56] = mBoardData[63] = GameItemKind.WHITE + GameItemKind.ROOK;
            mBoardData[57] = mBoardData[62] = GameItemKind.WHITE + GameItemKind.KNIGHT;
            mBoardData[58] = mBoardData[61] = GameItemKind.WHITE + GameItemKind.BISHOP;
            mBoardData[59] = GameItemKind.WHITE + GameItemKind.QUEEN;
            mBoardData[60] = GameItemKind.WHITE + GameItemKind.KING;
            mBoardData[48] = mBoardData[49] = mBoardData[50] = mBoardData[51] = mBoardData[52] = mBoardData[53] = mBoardData[54] = mBoardData[55] = GameItemKind.WHITE + GameItemKind.PAWN;

            TargetPlayer.mBoardData = mBoardData;
        }
        public void StartToPlay()
        {
            this.Status = GameStatus.PLAYING;
            TargetPlayer.Status = GameStatus.PLAYING;

            try
            {
                SendPacket(DataPacket.Build(DataPacketType.STARTGAME, mBoardData));
                TargetPlayer.SendPacket(DataPacket.Build(DataPacketType.STARTGAME, mBoardData));
            }
            catch { }

        }
        private void callbackRun()
        {
            do
            {
                try
                {
                    int iReadLen = mStream.Read(mBuffer, 0, DataPacket.BUFFER_SIZE);
                    if (iReadLen < 0)
                    {
                        Console.WriteLine("Read Error!");
                        continue;
                    }
                    DataPacket packet = DataPacket.Parse(mBuffer);

                    switch (packet.Type)
                    {
                        case DataPacketType.PLAYERNAME:
                            PlayerName = packet.Content.ToString();
                            Console.WriteLine("User name is " + PlayerName);
                            mServer.PlayerEntered(mId, PlayerName);
                            break;
                        case DataPacketType.HEARTBIT:
                            mLastHeartbitTime = DateTime.Now.Ticks;
                            break;
                        case DataPacketType.EXIT:
                            Console.WriteLine(PlayerName + " will exit!");
                            mServer.RemovePlayer(this);
                            break;
                        case DataPacketType.REQPLAY:
                            mServer.SendReqPlay((GameClientInfo)packet.Content, this);
                            break;
                        case DataPacketType.DENY:
                            mServer.DenyToPlay((GameClientInfo)packet.Content);
                            break;
                        case DataPacketType.ACCEPT:
                            mServer.StartToPlay((GameClientInfo)packet.Content, this);
                            break;
                        case DataPacketType.MOVEITEM:
                            TargetPlayer.SendPacket(DataPacket.Build(DataPacketType.MOVEITEM, (int[])packet.Content));
                            break;
                        case DataPacketType.GAMERESULT:
                            EndGame(DataPacketType.GAMERESULT, packet.Content);
                            break;
                        case DataPacketType.RESIGN:
                            EndGame(DataPacketType.RESIGN, null);
                            break;
                        case DataPacketType.PROMOTION:
                            TargetPlayer.SendPacket(DataPacket.Build(DataPacketType.PROMOTION, (int[])packet.Content));
                            break;
                    }
                }
                catch
                {
                    Console.WriteLine("Remove user " + PlayerName + " because connection is dropped!");
                    if (Status == GameStatus.PLAYING && TargetPlayer != null)
                    {
                        try
                        {
                            TargetPlayer.TargetPlayer = null;
                            TargetPlayer.SendPacket(DataPacket.Build(DataPacketType.EXITGAME, null));
                        }
                        catch { }
                    }
                    mServer.RemovePlayer(this);
                    break;
                }
            } while (!mIsStop);
        }

        private void EndGame(int resultPacketType, object objResult)
        {
            TargetPlayer.SendPacket(DataPacket.Build(resultPacketType, objResult));
            mServer.EndToPlay(this);
        }

        public void SendPacket(DataPacket p)
        {
            byte[] data = p.GetBytes();
            mStream.Write(data, 0, data.Length);
            mStream.Flush();
        }
    }
}
