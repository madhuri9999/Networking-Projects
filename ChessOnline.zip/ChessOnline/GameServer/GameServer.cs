﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

using GameLib.Game;
using GameLib.Net;

namespace GameServer
{
    public class GameServer
    {

        private List<GameClient> mPlayers;
        private TcpListener mTcpListener;
        private int mLastPlayerId = 0;

        private Thread mCheckHeartBitThread = null;

        private int mServerPort = 9090;
        private int mHeartbitTimeout = 10 * 1000;

        public GameServer(int iPort, int iHeartBitTimeout)
        {
            mServerPort = iPort;
            mHeartbitTimeout = iHeartBitTimeout;

            mPlayers = new List<GameClient>();
            mLastPlayerId = 1;
        }

        public void StartServer()
        {
            try
            {
                Console.WriteLine("Starting server...");
                mTcpListener = new TcpListener(IPAddress.Any, mServerPort);
                mTcpListener.Start();
                
                Console.WriteLine("Started server! Port is " + mServerPort);

                mCheckHeartBitThread = new Thread(new ThreadStart(callbackCheckHeartBit));
                mCheckHeartBitThread.Start();

                while (true)
                {
                    Socket sock = mTcpListener.AcceptSocket();
                    Console.WriteLine("Connected a client from " + ((IPEndPoint)sock.RemoteEndPoint).Address.ToString());

                    GameClient client = new GameClient(mLastPlayerId, sock, this);
                    mLastPlayerId++;
                    
                    List<GameClientInfo> arrUsers = new List<GameClientInfo>();
                    for (int i = 0; i < mPlayers.Count; i++)
                    {
                        if (mPlayers[i].Status == GameStatus.WAIT)
                            arrUsers.Add(new GameClientInfo(mPlayers[i].GetPlayerId(), mPlayers[i].PlayerName));
                    }
                    if (arrUsers.Count > 0)
                        client.SendPacket(DataPacket.Build(DataPacketType.PLAYERLIST, arrUsers));

                    mPlayers.Add(client);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception occured while server is running! ex: " + e.Message);
            }
        }
        public void StartToPlay(GameClientInfo receiver, GameClient sender)
        {
            GameClient client = null;
            for (int i = 0; i < mPlayers.Count; i++)
            {
                if (mPlayers[i].GetPlayerId() == receiver.ID)
                {
                    client = mPlayers[i];
                    break;
                }
            }
            if (client == null)
                return;

            sender.TargetPlayer = client;
            client.TargetPlayer = sender;

            client.InitBoard();
            client.StartToPlay();

            for (int i = 0; i < mPlayers.Count; i++)
            {
                if(mPlayers[i].GetPlayerId() != receiver.ID)
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.DELPLAYER, receiver.ID));
                }
                if(mPlayers[i].GetPlayerId() != sender.GetPlayerId())
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.DELPLAYER, sender.GetPlayerId()));
                }
            }
        }
        public void EndToPlay(GameClient player)
        {
            player.Status = GameStatus.WAIT;
            player.TargetPlayer.Status = GameStatus.WAIT;
            
            for (int i = 0; i < mPlayers.Count; i++)
            {
                if (mPlayers[i].GetPlayerId() != player.GetPlayerId())
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.ADDPLAYER, new GameClientInfo(player.GetPlayerId(), player.PlayerName)));
                }
                if (mPlayers[i].GetPlayerId() != player.TargetPlayer.GetPlayerId())
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.ADDPLAYER, new GameClientInfo(player.TargetPlayer.GetPlayerId(), player.TargetPlayer.PlayerName)));
                }
            }

            player.TargetPlayer = null;
        }
        public void DenyToPlay(GameClientInfo info)
        {
            for (int i = 0; i < mPlayers.Count; i++)
            {
                if (mPlayers[i].GetPlayerId() == info.ID)
                {
                    try
                    {
                        mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.DENY, info));
                    }
                    catch { }
                    break;
                }
            }
        }
        public void SendReqPlay(GameClientInfo receiver, GameClient sender)
        {
            for (int i = 0; i < mPlayers.Count; i++)
            {
                if (mPlayers[i].GetPlayerId() == receiver.ID)
                {
                    try
                    {
                        mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.REQPLAY, new GameClientInfo(sender.GetPlayerId(), sender.PlayerName)));
                    }
                    catch { }
                    break;
                }
            }
        }
        public void RemovePlayer(GameClient client)
        {
            mPlayers.Remove(client);
            for (int i = 0; i < mPlayers.Count; i++)
            {
                try
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.DELPLAYER, client.GetPlayerId()));
                }
                catch { }
            }
        }
        public void PlayerEntered(int iId, string strName)
        {
            for (int i = 0; i < mPlayers.Count; i++)
            {
                if (mPlayers[i].GetPlayerId() == iId)
                    continue;

                try
                {
                    mPlayers[i].SendPacket(DataPacket.Build(DataPacketType.ADDPLAYER, new GameClientInfo(iId, strName)));
                }
                catch { }
            }
        }

        private void callbackCheckHeartBit()
        {
            while (true)
            {
                List<GameClient> arrRemoveUsers = new List<GameClient>();
                for (int i = 0; i < mPlayers.Count; i++)
                {
                    if ((DateTime.Now.Ticks - mPlayers[i].LastHeartBitTime) > mHeartbitTimeout * 1000 * 1000)
                    {
                        arrRemoveUsers.Add(mPlayers[i]);
                    }
                }
                for (int i = 0; i < arrRemoveUsers.Count; i++)
                {
                    Console.WriteLine("Remove player " + arrRemoveUsers[i].PlayerName + " because connection is timeouted!");
                    RemovePlayer(arrRemoveUsers[i]);
                }

                try
                {
                    Thread.Sleep(mHeartbitTimeout);
                }
                catch { }
            }
        }
    }
}
