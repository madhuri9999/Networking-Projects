﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;

namespace GameServer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reading config...");
            int iServerPort = 0;
            int iHeartbitTimeout = 0;
            try
            {
                iServerPort = int.Parse(ConfigurationManager.AppSettings["SERVER_PORT"]);
                iHeartbitTimeout = int.Parse(ConfigurationManager.AppSettings["HEARTBIT_TIMEOUT"]);
            }
            catch
            {
                Console.WriteLine("Failed to read config!");
                return;
            }
            Console.WriteLine("Port: " + iServerPort + ", Heartbit: " + iHeartbitTimeout + "ms");
            new GameServer(iServerPort, iHeartbitTimeout).StartServer();
        }
    }
}
