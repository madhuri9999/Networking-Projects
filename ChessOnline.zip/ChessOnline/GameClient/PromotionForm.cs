﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using GameLib.Game;

namespace GameClient
{
    public partial class PromotionForm : Form
    {
        public PromotionForm()
        {
            InitializeComponent();
        }

        private int mSelectedType = GameItemKind.QUEEN;
        public int SelectedType { get { return mSelectedType; } }

        private void btnQueen_Click(object sender, EventArgs e)
        {
            mSelectedType = GameItemKind.QUEEN;
            Close();
        }

        private void btnRook_Click(object sender, EventArgs e)
        {
            mSelectedType = GameItemKind.ROOK;
            Close();
        }

        private void btnKnight_Click(object sender, EventArgs e)
        {
            mSelectedType = GameItemKind.KNIGHT;
            Close();
        }

        private void btnBishop_Click(object sender, EventArgs e)
        {
            mSelectedType = GameItemKind.BISHOP;
            Close();
        }
    }
}
