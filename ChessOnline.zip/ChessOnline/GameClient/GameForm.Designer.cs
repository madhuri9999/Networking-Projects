﻿namespace GameClient
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.board = new GameLib.Game.GameBoard();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblBlack = new System.Windows.Forms.Label();
            this.lblWhiteTime = new System.Windows.Forms.Label();
            this.btnCastling = new System.Windows.Forms.Button();
            this.btnGiveup = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.board)).BeginInit();
            this.SuspendLayout();
            // 
            // board
            // 
            this.board.CanMove = false;
            this.board.Location = new System.Drawing.Point(12, 12);
            this.board.Name = "board";
            this.board.PlayerColor = 0;
            this.board.Size = new System.Drawing.Size(600, 600);
            this.board.TabIndex = 19;
            this.board.TabStop = false;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label7.Location = new System.Drawing.Point(499, 615);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 21);
            this.label7.TabIndex = 18;
            this.label7.Text = "Black:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(11, 615);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 21);
            this.label6.TabIndex = 17;
            this.label6.Text = "White:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblBlack
            // 
            this.lblBlack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlack.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblBlack.Location = new System.Drawing.Point(544, 615);
            this.lblBlack.Name = "lblBlack";
            this.lblBlack.Size = new System.Drawing.Size(68, 21);
            this.lblBlack.TabIndex = 16;
            this.lblBlack.Text = "00:00:00";
            this.lblBlack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblWhiteTime
            // 
            this.lblWhiteTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhiteTime.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblWhiteTime.Location = new System.Drawing.Point(66, 615);
            this.lblWhiteTime.Name = "lblWhiteTime";
            this.lblWhiteTime.Size = new System.Drawing.Size(68, 21);
            this.lblWhiteTime.TabIndex = 15;
            this.lblWhiteTime.Text = "00:00:00";
            this.lblWhiteTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCastling
            // 
            this.btnCastling.Location = new System.Drawing.Point(192, 650);
            this.btnCastling.Name = "btnCastling";
            this.btnCastling.Size = new System.Drawing.Size(106, 37);
            this.btnCastling.TabIndex = 20;
            this.btnCastling.Text = "CASTLING";
            this.btnCastling.UseVisualStyleBackColor = true;
            this.btnCastling.Click += new System.EventHandler(this.btnCastling_Click);
            // 
            // btnGiveup
            // 
            this.btnGiveup.Location = new System.Drawing.Point(322, 650);
            this.btnGiveup.Name = "btnGiveup";
            this.btnGiveup.Size = new System.Drawing.Size(106, 37);
            this.btnGiveup.TabIndex = 21;
            this.btnGiveup.Text = "GIVE UP";
            this.btnGiveup.UseVisualStyleBackColor = true;
            this.btnGiveup.Click += new System.EventHandler(this.btnGiveup_Click);
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(625, 699);
            this.Controls.Add(this.btnGiveup);
            this.Controls.Add(this.btnCastling);
            this.Controls.Add(this.board);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblBlack);
            this.Controls.Add(this.lblWhiteTime);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GameForm";
            this.Text = "GameForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GameForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.board)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GameLib.Game.GameBoard board;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblBlack;
        private System.Windows.Forms.Label lblWhiteTime;
        private System.Windows.Forms.Button btnCastling;
        private System.Windows.Forms.Button btnGiveup;
    }
}