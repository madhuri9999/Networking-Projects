﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using GameLib.Game;

namespace GameClient
{
    public partial class GameForm : Form
    {

        public GameForm(MainForm mainFrm)
        {
            InitializeComponent();

            this.Text = MainForm.APP_NAME;
            mParent = mainFrm;
            
        }
        public void SetPlayerName(string strName)
        {
            this.Text = MainForm.APP_NAME + " - " + strName;
        }
        private MainForm mParent;

        public GameBoard Board { get { return board; } }
        public Label TimeWhite { get { return lblWhiteTime; } }
        public Label TimeBlack { get { return lblBlack; } }

        private void btnCastling_Click(object sender, EventArgs e)
        {
            if (!Board.CanMove || !Board.Castling())
            {
                MessageBox.Show("Invalid to move!", MainForm.APP_NAME);
            }
        }

        private void btnGiveup_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are you sure to give up from game?", MainForm.APP_NAME, MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            mParent.Resign();
        }

        private void GameForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            btnGiveup_Click(null, null);
        }
    }
}
