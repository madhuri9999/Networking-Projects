﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.IO;
using System.Net.Sockets;
using System.Threading;

using GameLib.Net;
using GameLib.Game;

namespace GameClient
{
    public class Client
    {

        private const int SOCKET_TIMEOUT = 60000;

        private MainForm mApp;
        private string mServerIP;
        private int mServerPort;
        private string mPlayerName;
        private byte[] mBuffer;

        private TcpClient mTcpClient;
        private NetworkStream mStream;

        private bool mIsStop;

        private Thread mMainThread = null;
        private Thread mHeartbitThread = null;

        public Client(MainForm app)
        {
            mApp = app;
            mIsStop = false;
            mMainThread = null;
            mBuffer = new byte[DataPacket.BUFFER_SIZE];
        }

        public bool Start(string strServerIP, int iPort, string strUserName)
        {
            mServerIP = strServerIP;
            mServerPort = iPort;
            mPlayerName = strUserName;

            try
            {
                mTcpClient = new TcpClient();
                mTcpClient.SendTimeout = mTcpClient.ReceiveTimeout = SOCKET_TIMEOUT;
                mTcpClient.Connect(mServerIP, mServerPort);
                mStream = mTcpClient.GetStream();

                sendUserName();

                mIsStop = true;
                mMainThread = new Thread(new ThreadStart(callbackRun));
                mMainThread.Start();
                mHeartbitThread = new Thread(new ThreadStart(callbackHeartbit));
                mHeartbitThread.Start();
                return true;
            }
            catch { }
            return false;
        }
        public void Stop()
        {
            if (!mIsStop)
                return;

            mIsStop = false;

            try
            {
                sendExit();
            }
            catch { }

            if (mMainThread != null)
            {
                mMainThread.Interrupt();
                mMainThread = null;
            }

            if (mHeartbitThread != null)
            {
                mHeartbitThread.Interrupt();
                mHeartbitThread = null;
            }
        }
        public void SendPacket(DataPacket p)
        {
            byte[] data = p.GetBytes();

            mStream.Write(data, 0, data.Length);
            mStream.Flush();
        }

        private void callbackRun()
        {
            while (mIsStop)
            {
                try
                {
                    int iReadLen = mStream.Read(mBuffer, 0, DataPacket.BUFFER_SIZE);
                    if (iReadLen < 0)
                    {
                        continue;
                    }
                    DataPacket packet = DataPacket.Parse(mBuffer);
                    if (packet == null)
                    {
                        continue;
                    }

                    switch (packet.Type)
                    {
                        case DataPacketType.ADDPLAYER:
                            mApp.AddPlayer((GameClientInfo)(packet.Content));
                            break;
                        case DataPacketType.DELPLAYER:
                            mApp.RemovePlayer((int)packet.Content);
                            break;
                        case DataPacketType.PLAYERLIST:
                            List<GameClientInfo> arrUsers = (List<GameClientInfo>)packet.Content;
                            for (int i = 0; i < arrUsers.Count; i++)
                            {
                                mApp.AddPlayer(arrUsers[i]);
                            }
                            break;
                        case DataPacketType.REQPLAY:
                            mApp.ReceiveReqPlay((GameClientInfo)packet.Content);
                            break;
                        case DataPacketType.DENY:
                            mApp.ReceiveDeny();
                            break;
                        case DataPacketType.STARTGAME:
                            mApp.StartPlay((byte[])packet.Content);
                            break;
                        case DataPacketType.MOVEITEM:
                            mApp.ReceiveItemMove((int[])packet.Content);
                            break;
                        case DataPacketType.GAMERESULT:
                            mApp.EndGame(((byte)packet.Content) == 1, false);
                            break;
                        case DataPacketType.EXITGAME:
                            mApp.ReceiveExitGame();
                            break;
                        case DataPacketType.RESIGN:
                            mApp.ReceiveResign();
                            break;
                        case DataPacketType.PROMOTION:
                            mApp.ReceivePromotion((int[])packet.Content);
                            break;
                    }

                }
                catch { }
            }
        }
        private void callbackHeartbit()
        {
            while (mIsStop)
            {
                try
                {
                    sendHeartBit();
                    Thread.Sleep(5 * 1000);
                }
                catch { }
            }
        }

        private void sendExit()
        {
            SendPacket(DataPacket.Build(DataPacketType.EXIT, null));
        }
        private void sendUserName()
        {
            SendPacket(DataPacket.Build(DataPacketType.PLAYERNAME, mPlayerName));
        }
        private void sendHeartBit()
        {
            SendPacket(DataPacket.Build(DataPacketType.HEARTBIT, null));
        }
    }
}
