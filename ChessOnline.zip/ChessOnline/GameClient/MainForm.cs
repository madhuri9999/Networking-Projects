﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using GameLib.Game;
using GameLib.Net;

using System.Net;
using System.IO;
using System.Net.Sockets;

namespace GameClient
{
    public partial class MainForm : Form, GameBoardInterface
    {
        public const string APP_NAME = "Chess Game 1.0";
        private const string WIN_MSG = "=============== WIN! ===============";
        private const string LOSE_MSG = "=============== LOSE! ===============";
        private Client mClient;

        private List<GameClientInfo> mWaitClients;

        private int mPlayTime;

        private Label mLblTimeOfMine;
        private Label mLblTimeOfOther;

        private GameForm mGameForm;

        private bool IsPlaying { get; set; }

        public MainForm()
        {
            InitializeComponent();

            tbxName.Text = "";
            tbxServer.Text = "127.0.0.1";
            tbxPort.Text = "9090";

            this.Text = APP_NAME;

            mClient = new Client(this);
            mWaitClients = new List<GameClientInfo>();

            lstUsers.DisplayMember = "Name";
            lstUsers.ValueMember = "ID";

            mGameForm = new GameForm(this);
            mGameForm.Board.SetBoardInterface(this);

            mGameForm.Board.CanMove = false;

            timer.Start();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Text == "Connect")
            {
                string strUserName = tbxName.Text;
                if (strUserName == "")
                {
                    MessageBox.Show("Please input the name of player!", APP_NAME);
                    return;
                }

                string strServerIP = tbxServer.Text;
                if (strServerIP == "")
                {
                    MessageBox.Show("Please input the ip address of server!", APP_NAME);
                    return;
                }

                int iServerPort = 0;
                try
                {
                    iServerPort = int.Parse(tbxPort.Text);
                    if (iServerPort < 1000 || iServerPort > 65536)
                        throw new Exception();
                }
                catch
                {
                    MessageBox.Show("Please input the valid port of server!", APP_NAME);
                    return;
                }

                btnConnect.Enabled = false;
                if (!mClient.Start(strServerIP, iServerPort, strUserName))
                {
                    MessageBox.Show("Failed to connect to server!", APP_NAME);
                    btnConnect.Enabled = true;
                    return;
                }
                btnConnect.Text = "Disconnect";
                btnConnect.Enabled = true;
                tbxName.Enabled = false;
                tbxServer.Enabled = false;
                tbxPort.Enabled = false;
                mGameForm.SetPlayerName(strUserName);
            }
            else
            {
                if (MessageBox.Show("Are you sure to disconnect from server?", APP_NAME, MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;

                mClient.Stop();
                btnConnect.Text = "Connect";
                mWaitClients.Clear();
                RefreshPlayers();
                tbxName.Enabled = true;
                tbxServer.Enabled = true;
                tbxPort.Enabled = true;
            }
        }
       
        public void Resign()
        {
            mClient.SendPacket(DataPacket.Build(DataPacketType.RESIGN, null));


            processEndGame();
            MessageBox.Show(LOSE_MSG, APP_NAME);
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (!mGameForm.Board.CanMove) return;

            mPlayTime++;
            mLblTimeOfMine.Text = getTimeFormat(mPlayTime);
        }
        private string getTimeFormat(int iTime)
        {
            return string.Format("{0:D2}:{1:D2}:{2:D2}", iTime / 3600, (iTime % 3600) / 60, (iTime % 3600) % 60);
        }

        public void ReceiveDeny()
        {
            Invoke((MethodInvoker)delegate
            {
                MessageBox.Show("The player has denied to play!", APP_NAME);
            });
        }
        public void ReceiveReqPlay(GameClientInfo info)
        {
            Invoke((MethodInvoker)delegate
            {
                if (MessageBox.Show("Would you like to play with " + info.Name + "?", APP_NAME, MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    mClient.SendPacket(DataPacket.Build(DataPacketType.DENY, info));
                }
                else
                {
                    mGameForm.Board.PlayerColor = GameItemKind.BLACK;
                    mLblTimeOfMine = mGameForm.TimeBlack;
                    mLblTimeOfOther = mGameForm.TimeWhite;
                    mClient.SendPacket(DataPacket.Build(DataPacketType.ACCEPT, info));
                }
            });

        }

        public void SendReqPlay(GameClientInfo info)
        {
            if (lstUsers.SelectedIndex < 0)
                return;
            
            if (MessageBox.Show("Would you like to play with " + info.Name + "?", APP_NAME, MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            try
            {
                mGameForm.Board.PlayerColor = GameItemKind.WHITE;
                mLblTimeOfMine = mGameForm.TimeWhite;
                mLblTimeOfOther = mGameForm.TimeBlack;
                mClient.SendPacket(DataPacket.Build(DataPacketType.REQPLAY, info));
            }
            catch { }
        }
        
        public void ReceiveResign()
        {
            Invoke((MethodInvoker)delegate
            {
                processEndGame();
                MessageBox.Show(WIN_MSG, APP_NAME);
            });
        }

        public void ReceiveExitGame()
        {
            Invoke((MethodInvoker)delegate
            {
                processEndGame();
                MessageBox.Show("Player has exited from game!", APP_NAME);
            });
        }

        private void processEndGame()
        {
            IsPlaying = false;

            mPlayTime = 0;
            mGameForm.Board.CanMove = false;
            
            mGameForm.Board.Reset();
            mLblTimeOfMine.Text = mLblTimeOfOther.Text = "00:00:00";
            mGameForm.Hide();
        }

        public void ReceiveItemMove(int[] arrXY)
        {
            Invoke((MethodInvoker)delegate
            {
                mGameForm.Board.CanMove = true;
                int iMoveCount = (arrXY.Length - 1) / 4;
                for (int i = 0; i < iMoveCount; i++)
                {
                    mGameForm.Board.MoveItem(arrXY[4 * i + 1], arrXY[4 * i + 2], arrXY[4 * i + 3], arrXY[4 * i + 4]);
                }

                string strTimeText = getTimeFormat(arrXY[arrXY.Length - 1]);
                mLblTimeOfOther.Text = strTimeText;
            });
        }

        public void StartPlay(byte[] boardData)
        {
            IsPlaying = true;

            Invoke((MethodInvoker)delegate
            {
                mGameForm.Left = this.Left;
                mGameForm.Top = this.Top + this.Height;
                mGameForm.Show();

                mGameForm.Board.Initialize(boardData);
                mPlayTime = 0;

                if (mGameForm.Board.PlayerColor == GameItemKind.WHITE)
                {
                    mGameForm.Board.CanMove = true;
                }
            });
        }
        public void AddPlayer(GameClientInfo info)
        {
            mWaitClients.Add(info);

            RefreshPlayers();
        }
        public void RemovePlayer(int iId)
        {
            for (int i = 0; i < mWaitClients.Count; i++)
            {
                if (mWaitClients[i].ID == iId)
                {
                    mWaitClients.RemoveAt(i);
                    break;
                }
            }

            RefreshPlayers();
        }

        public void RefreshPlayers()
        {
            Invoke((MethodInvoker)delegate
            {
                lstUsers.Items.Clear();
                for (int i = 0; i < mWaitClients.Count; i++)
                {
                    lstUsers.Items.Add(mWaitClients[i]);
                }
            });
        }

        public void ReceivePromotion(int[] arrData)
        {
            Invoke((MethodInvoker)delegate
            {
                mGameForm.Board.CanMove = true;

                string strTimeText = getTimeFormat(arrData[5]);
                mLblTimeOfOther.Text = strTimeText;
                mGameForm.Board.PromotionByOther(arrData);
            });
        }

        
        #region GameBoardInterface
        public void ShowPromotionForm()
        {
            PromotionForm frm = new PromotionForm();
            frm.ShowDialog();
            mGameForm.Board.PromotionBySelf(frm.SelectedType);
        }

        public void MoveItem(int iOldX, int iOldY, int iNewX, int iNewY)
        {
            try
            {
                mClient.SendPacket(DataPacket.Build(DataPacketType.MOVEITEM, new int[] { 1, iOldX, iOldY, iNewX, iNewY, mPlayTime }));
                mGameForm.Board.CanMove = false;
            }
            catch { }
        }

        public void MoveItem(int iOldX1, int iOldY1, int iNewX1, int iNewY1, int iOldX2, int iOldY2, int iNewX2, int iNewY2)
        {
            try
            {
                mClient.SendPacket(DataPacket.Build(DataPacketType.MOVEITEM, new int[] { 2, iOldX1, iOldY1, iNewX1, iNewY1, iOldX2, iOldY2, iNewX2, iNewY2, mPlayTime }));
                mGameForm.Board.CanMove = false;
            }
            catch { }
        }

        public void EndGame(bool bWin, bool bIsByMine)
        {
            if (bIsByMine)
            {
                try
                {
                    mClient.SendPacket(DataPacket.Build(DataPacketType.GAMERESULT, (byte)(bWin ? 0 : 1)));
                }
                catch { }
            }

            Invoke((MethodInvoker)delegate
            {
                processEndGame();
                MessageBox.Show(bWin ? WIN_MSG : LOSE_MSG, APP_NAME);
            });
        }

        public void SendPromotion(int iOldX, int iOldY, int iNewX, int iNewY, int iType)
        {
            try
            {
                mClient.SendPacket(DataPacket.Build(DataPacketType.PROMOTION, new int[] { iOldX, iOldY, iNewX, iNewY, iType, mPlayTime }));
            }
            catch { }
        }
        #endregion

        private void lstUsers_DoubleClick(object sender, EventArgs e)
        {
            int iIndex = lstUsers.IndexFromPoint(((MouseEventArgs)e).Location);
            if(iIndex != ListBox.NoMatches && iIndex >= 0 && iIndex < mWaitClients.Count)
            {
                if(IsPlaying)
                {
                    MessageBox.Show("You are already playing the game!", APP_NAME);
                    return;
                }
                SendReqPlay(mWaitClients[iIndex]);
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            mClient.Stop();
        }
    }
}
