import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;



public class SAWSender implements Runnable{
	

	private final Random uniqueNumber = new Random(System.currentTimeMillis());
	private final int loss;
	private final DisplayFrame frame;
	String host;
	int port;
	InputStream inputStream;

	public SAWSender(int loss, DisplayFrame frame,String hostName, int port, InputStream inputStream) {
		this.loss = loss;
		this.frame = frame;
		this.host=hostName;
		this.port=port;
		this.inputStream=inputStream;
		 Thread senderThread=new Thread(this);
		 senderThread.start();
	}

	@Override
	public void run() {
		frame.displaySenderBytes().append(" Through Stop and Waiting method Sending the file ..."+"\n");
		int receiveBytes = Generic.fBytes;
		int sent = 0;
		int lost = 0;
		long start = System.currentTimeMillis();
		try (DatagramSocket socket = new DatagramSocket()) {
			socket.setSoTimeout(500);
			byte[] data = new byte[Generic.pData];
			while (true) {
				int size = inputStream.read(data, Generic.bSize,
						data.length - Generic.bSize);
				if (size < 0) {
					size = 0;
					receiveBytes = Generic.lpData;
					data = new byte[Generic.bSize];
				}
				size += Generic.bSize;

				do {
					byte[] receiveFrom = GetByte.afterBufferData(receiveBytes);
					System.arraycopy(receiveFrom, 0, data, 0,
							receiveFrom.length);
					sent += size;

					int randomNumber = uniqueNumber.nextInt(100);
					if (randomNumber < loss) {
						lost += size;
						frame.displaySenderBytes().append("Lost package " + receiveBytes+"\n");
					} else {
						frame.displaySenderBytes().append("Sending package " + receiveBytes + " (" + size + ")"+"\n");
						InetAddress address = InetAddress.getByName(host);
						DatagramPacket packet = new DatagramPacket(data,
								size, address, port);
						socket.send(packet);
					}

					byte[] responseData = new byte[Generic.bSize];
					DatagramPacket responsePacket = new DatagramPacket(
							responseData, responseData.length);
					try {
						socket.receive(responsePacket);
						int responseV = GetByte.beforeBufferData(responseData);
						if (responseV == receiveBytes) {
							break;
						}
					} catch (IOException e) {
						;
					}
				} while (true);

				if (receiveBytes == Generic.lpData) {
					break;
				}
				receiveBytes++;
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		long end = System.currentTimeMillis();
		frame.displaySenderBytes().append("Total Time Taken: " + (end - start) + "ms"+"\n");
		frame.displaySenderBytes().append("Sent No Of Bytes: " + sent+"\n");
		frame.displaySenderBytes().append("Lost Number Of Bytes: " + lost+"\n");
	}

	
}
