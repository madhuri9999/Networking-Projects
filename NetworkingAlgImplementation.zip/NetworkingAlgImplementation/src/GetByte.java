import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

public class GetByte {

	private GetByte() {

	}

	public static byte[] afterBufferData(int v) {
		byte[] bytes = new byte[Generic.bSize];
		int r = v;
		for (int i = Generic.bSize - 1; i >= 0; i--) {
			bytes[i] = (byte) (r % 256 + Byte.MIN_VALUE);
			r /= 256;
		}
		return bytes;
	}

	public static int  beforeBufferData(byte[] bytes) {
		int v = 0;
		for (int i = 0; i < Generic.bSize; i++) {
			v = v * 256 + ((int) bytes[i] - Byte.MIN_VALUE);
		}
		return v;
	}

	public static byte[] read(InputStream inputStream, byte[] bytes, int s) {
		try {
			int length = inputStream.read(bytes, s, bytes.length - s);
			if (length < 0) {
				return null;
			}

			int size = s + length;
			if (size < bytes.length) {
				return Arrays.copyOf(bytes, size);
			} else {
				return bytes;
			}
		} catch (IOException e) {
			return null;
		}
	}
}
