

public class ByteContent {
		private final int buffData;
	private final byte[] content;

	public ByteContent(byte[] versionAndData) {
		buffData = GetByte.beforeBufferData(versionAndData);
		content = new byte[versionAndData.length - Generic.bSize];
		System.arraycopy(versionAndData, Generic.bSize, content, 0,
				content.length);
	}

	public ByteContent(int version, byte[] data) {
		this.buffData = version;
		this.content = data;
	}

	public int getVersion() {
		return buffData;
	}

	public byte[] getData() {
		return content;
	}
}
