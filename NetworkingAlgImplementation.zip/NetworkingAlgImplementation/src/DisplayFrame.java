import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class DisplayFrame extends JFrame {
	int GBN_WINDOW_SIZE = 3;
	public static void main(String[] strings) {
		new DisplayFrame().setVisible(true);
	}
	private final JTextField portField = new JTextField(9);
	private final JTextField lossField = new JTextField(10);
	private final TextArea displaySenderBytes = new TextArea();
	private final JTextField hostName = new JTextField(10);
	private final TextArea displayReceiverBytes = new TextArea();
	private final JButton transferButton = new JButton("Transfer");
	String[] algList = { "Receive", "SAW", "GBN" };
	@SuppressWarnings("unchecked")
	JList algorithmlist = new JList(algList);

	public DisplayFrame() {
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.setLayout(new BorderLayout());

		this.add(new JScrollPane(displaySenderBytes), BorderLayout.EAST);
		this.add(new JScrollPane(displayReceiverBytes), BorderLayout.WEST);
		JPanel jpanel = new JPanel();
		this.setBackground(Color.BLACK);
		jpanel.setBackground(Color.LIGHT_GRAY);
		this.add(jpanel, BorderLayout.CENTER );
		jpanel.setLayout(new FlowLayout());
		jpanel.add(new JLabel("Host"));
		jpanel.add(hostName);
		hostName.setText("");
		jpanel.add(new JLabel("Port"));
		jpanel.add(portField);
		portField.setText("");
		jpanel.add(new JLabel("Loss%"));
		jpanel.add(lossField);
		lossField.setText("");
		//algorithmlist.setSelectedIndex(1);
		jpanel.add(new JLabel("Algorithm List::"));
		jpanel.add(algorithmlist);
		//jpanel.add(new JScrollPane(algorithmlist));
		jpanel.add(transferButton);
		transferButton.addActionListener(listener);
	
	}

	public TextArea displaySenderBytes() {
		return displaySenderBytes;
	}

	public TextArea displayReceiverBytes() {
		return displayReceiverBytes;
	}
	private final ActionListener listener = new ActionListener() {
		@SuppressWarnings("unused")
		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				String host = hostName.getText();
				String name=(String) algorithmlist.getSelectedValue();
				int port;
				int loss;
				
				try {
					port = Integer.parseInt(portField.getText());
					loss = Integer.parseInt(lossField.getText());
				
					if (name.equalsIgnoreCase("receive")) {
						@SuppressWarnings("unused")
						Receiver receiver=new Receiver(port, DisplayFrame.this);
						
					} else if (name.equalsIgnoreCase("GBN")) {
						InputStream inputStream = new FileInputStream("COSC635_P2_DataSent.txt");
						@SuppressWarnings("unused")
						GoBackNSender goBackNSender = new GoBackNSender(loss, GBN_WINDOW_SIZE, DisplayFrame.this,host, port, inputStream);
						
					} else if (name.equalsIgnoreCase("SAW")) {
						InputStream inputStream = new FileInputStream("COSC635_P2_DataSent.txt");
						SAWSender sawSender = new SAWSender(loss, DisplayFrame.this,host,port,inputStream);						
					}

				} catch (Exception e2) {
					throw new RuntimeException(e2);
				}

			} catch (Exception e2) {
				JOptionPane.showMessageDialog(DisplayFrame.this, "Check the inputs!");
			}
		}
	};
	public void append(String text) {
		displaySenderBytes.append(text + "\n");
		displayReceiverBytes.append(text + "\n");
	}
}
