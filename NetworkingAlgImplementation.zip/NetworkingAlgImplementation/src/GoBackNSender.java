import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;


public class GoBackNSender implements Runnable{

	private final Random r = new Random(System.currentTimeMillis());
	private final int packetLoss;
	private final DisplayFrame frame;
	private final int window;
	private final List<byte[]> packets = new LinkedList<>();
	String host;
	int port;
	InputStream inputStream;

	public GoBackNSender(int loss, int window, DisplayFrame frame,String host, int port, InputStream inputStream) {
		this.packetLoss = loss;
		this.window = window;
		this.frame = frame;
		this.host=host;
		this.port=port;
		this.inputStream=inputStream;
		Thread goBackNSenderThread=new Thread(this);
		   goBackNSenderThread.start();
	}

	@Override
	public void run() {
		frame.append("Sending file by GoBackN method..."+"\n");
		packets.clear();
		long start = System.currentTimeMillis();
		int sent = 0;
		int lost = 0;
		int v = Generic.fBytes;
		try (DatagramSocket socket = new DatagramSocket()) {
			socket.setSoTimeout(500);
			while (true) {
				while (packets.size() < window) {
					byte[] data = new byte[Generic.pData];
					data = GetByte.read(inputStream, data,
							Generic.bSize);
					if (data == null) {
						break;
					}
					packets.add(data);
				}

				if (packets.size() == 0) {
					packets.add(new byte[Generic.bSize]);
					v = Generic.lpData;
				}

				for (int i = 0; i < packets.size(); i++) {
					byte[] data = packets.get(i);
					int version = v + i;
					byte[] vb = GetByte.afterBufferData(version);
					System.arraycopy(vb, 0, data, 0,
							vb.length);
					int length = data.length;
					sent += length;

					int randomNumber = r.nextInt(100);
					if (randomNumber < packetLoss) {
						lost += length;
						frame.displaySenderBytes().append("Lost package " + version+"\n");
					} else {
						frame.displaySenderBytes().append("Sending package " + version + " (" + length + ")"+"\n");
						InetAddress ip = InetAddress.getByName(host);
						DatagramPacket sendPacket = new DatagramPacket(data,
								length, ip, port);
						socket.send(sendPacket);
					}
				}

				
				byte[] responseData = new byte[Generic.bSize];
				DatagramPacket responsePacket = new DatagramPacket(responseData,
						responseData.length);
				int maxV = Integer.MIN_VALUE;
				while (true) {
					try {
						socket.receive(responsePacket);
						responseData = responsePacket.getData();
						int rV = GetByte.beforeBufferData(responseData);
						if (rV > maxV) {
							maxV = rV;
						}
					} catch (IOException e) {
						break;
					}
				}

				if (maxV == Generic.lpData) {
					break;
				}

				for (; v <= maxV; v++) {
					packets.remove(0);
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		long end = System.currentTimeMillis();
		frame.displaySenderBytes().append("Total Time: " + (end - start) + "ms"+"\n");
		frame.displaySenderBytes().append("Sent Bytes: " + sent+"\n");
		frame.displaySenderBytes().append("Lost Bytes: " + lost+"\n");
	}

	

}
