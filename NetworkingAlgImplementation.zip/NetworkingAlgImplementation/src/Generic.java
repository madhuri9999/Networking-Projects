
public abstract class Generic {

	public Generic() {
		// TODO Auto-generated constructor stub
	}
	public static int  bSize = 4;
	public static int pData = 1024;
	public static int lpData = 99999;	
	public static int fBytes = 1;
}

