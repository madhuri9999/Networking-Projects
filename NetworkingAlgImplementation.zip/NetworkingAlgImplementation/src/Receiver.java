
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;



public class Receiver implements Runnable {

		private final int port;
	private final DisplayFrame frame;
	private int nextAvaByte = Generic.fBytes;


	public Receiver(int port, DisplayFrame frame) {
		this.frame = frame;
		this.port = port;
		 Thread receiverThread=new Thread(this);
			receiverThread.start();
	}

	@Override
	public void run() {
		
		frame.displayReceiverBytes().append("Entered in to Receiver Class..."+"\n");
	
		byte[] getData = new byte[Generic.pData];
		DatagramPacket packet = new DatagramPacket(getData, getData.length);
		try (OutputStream outputStream = new FileOutputStream(
				"COSC635_P2_DataRecieved.txt");
				DatagramSocket socket = new DatagramSocket(port);) {
			socket.setSoTimeout(1000);
			while (true) {
				try {
					socket.receive(packet);
					byte[] bytes = Arrays.copyOf(packet.getData(),
							packet.getLength());
					ByteContent content = new ByteContent(bytes);

					int buffer = content.getVersion();
					if (buffer == Generic.lpData) {
						frame.displayReceiverBytes().append("Completed..."+"\n");
						nextAvaByte = Generic.fBytes;
					} else if (buffer == nextAvaByte) {
						frame.displayReceiverBytes().append("Received packet " + nextAvaByte + " ("
								+ content.getData().length + ")"+"\n");
						outputStream.write(content.getData());
						nextAvaByte++;
					} else {
						frame.displayReceiverBytes().append("Received unknown packet " + buffer+"\n");
						buffer = nextAvaByte - 1;
					}

					byte[] responseData = GetByte.afterBufferData(buffer);
					InetAddress ip = packet.getAddress();
					int port = packet.getPort();
					DatagramPacket responsePacket = new DatagramPacket(
							responseData, responseData.length, ip, port);
					socket.send(responsePacket);

					if (buffer == Generic.lpData) {
						break;
					}
				} catch (Exception e) {
					;
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
